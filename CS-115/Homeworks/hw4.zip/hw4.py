'''
Created on Oct 2, 2017

@author: hrana2 - Himanshu Rana 
"I pledge my honor that I have abided by the Stevens Honor System" 
'''

def pascal_row(n):
    if n == 0: 
        return [1]
    elif n == 1: 
        return [1, 1]
    return store_row([1, 1], n)

count = 0
def store_row(L, n):
   
    global count
    count += 1
    
    if  n == count: 
        count = 0
        return L 
    else: 
        if count == 1: 
            return store_row(previous_row(L, count + 1), n)
        return store_row(previous_row(L, count + 1), n)
       
def previous_row(L, n):
    if len(L) == 1: 
        return [1]
    elif len(L) == n: 
        return [1] + previous_row(L, n + 1)
    return [L[0] + L[1]] + previous_row(L[1:], n)
    
def pascal_triangle(n):
    if n == 0: 
        return [[1]]
    return pascal_triangle(n - 1) + [pascal_row(n)]


print(pascal_row(5))
print(pascal_triangle(5))